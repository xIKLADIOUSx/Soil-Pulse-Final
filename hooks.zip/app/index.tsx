import React, { useEffect } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Redirect } from 'expo-router';
import { getData, STORAGE_KEYS } from '@/utils/storage';
import { colors, spacing, typography } from '@/theme';
import { User } from '@/types';

/**
 * Initial loading screen and router
 * Checks authentication status and redirects accordingly
 */
export default function Index() {
  // For demo purposes, we'll simulate the auth check
  // In a real app, you'd use something like useEffect with a check
  
  // Mock user check - will redirect to auth or main app based on login status
  // Replace with actual auth check
  const isAuthenticated = false; // Set to true to bypass login for testing
  
  if (isAuthenticated) {
    return <Redirect href="/(tabs)" />;
  } else {
    return <Redirect href="/(auth)/login" />;
  }
  
  // If we need to do async checks, we could show a loading screen here
  return (
    <View style={styles.container}>
      <Text style={styles.title}>SoilSense AI</Text>
      <Text style={styles.subtitle}>Advanced soil analysis</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
  },
  title: {
    ...typography.displayMedium,
    color: colors.primary[500],
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.bodyLarge,
    color: colors.neutral[600],
  },
});