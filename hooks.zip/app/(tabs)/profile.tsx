import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { Header } from '@/components/Header';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { colors, spacing, typography } from '@/theme';
import { useRouter } from 'expo-router';
import { User } from '@/types';
import { 
  LogOut, 
  User as UserIcon, 
  Settings, 
  Bell, 
  HelpCircle, 
  Shield, 
  Globe, 
  Database
} from 'lucide-react-native';

// Mock user data
const mockUser: User = {
  id: 'user1',
  email: 'john.doe@example.com',
  name: 'John Doe',
  role: 'farmer',
  profileImageUrl: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
  farms: [
    {
      id: 'farm1',
      name: 'Green Valley Farm',
      location: {
        latitude: 37.7749,
        longitude: -122.4194,
      },
      size: 250,
      crops: ['Corn', 'Soybeans', 'Wheat'],
    },
  ],
};

export default function ProfileScreen() {
  const router = useRouter();
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [offlineMode, setOfflineMode] = useState(false);
  const [highQualityImages, setHighQualityImages] = useState(true);
  
  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Logout',
          onPress: () => {
            // Clear authentication and navigate to login
            router.replace('/(auth)/login');
          },
          style: 'destructive',
        },
      ]
    );
  };
  
  const handleEditProfile = () => {
    router.push('/profile/edit');
  };
  
  const handleSettingsPress = () => {
    router.push('/settings');
  };
  
  const handleFarmPress = (farmId: string) => {
    router.push(`/farm/${farmId}`);
  };
  
  return (
    <View style={styles.container}>
      <Header title="Profile" />
      
      <ScrollView style={styles.scrollView}>
        <View style={styles.profileSection}>
          <Image 
            source={{ uri: mockUser.profileImageUrl }}
            style={styles.profileImage}
          />
          <Text style={styles.profileName}>{mockUser.name}</Text>
          <Text style={styles.profileEmail}>{mockUser.email}</Text>
          <View style={styles.roleBadge}>
            <Text style={styles.roleText}>
              {mockUser.role.charAt(0).toUpperCase() + mockUser.role.slice(1)}
            </Text>
          </View>
          
          <Button
            title="Edit Profile"
            variant="outline"
            size="small"
            onPress={handleEditProfile}
            style={styles.editButton}
            icon={<UserIcon size={16} color={colors.primary[500]} />}
          />
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>My Farms</Text>
          
          {mockUser.farms?.map(farm => (
            <Card 
              key={farm.id}
              onPress={() => handleFarmPress(farm.id)}
              style={styles.farmCard}
            >
              <View style={styles.farmHeader}>
                <Text style={styles.farmName}>{farm.name}</Text>
                <Text style={styles.farmSize}>{farm.size} acres</Text>
              </View>
              
              <Text style={styles.farmLocation}>
                Lat: {farm.location.latitude.toFixed(4)}, Lon: {farm.location.longitude.toFixed(4)}
              </Text>
              
              <View style={styles.cropContainer}>
                <Text style={styles.cropsLabel}>Crops: </Text>
                <Text style={styles.cropsText}>{farm.crops.join(', ')}</Text>
              </View>
            </Card>
          ))}
          
          <TouchableOpacity 
            style={styles.addFarmButton}
            onPress={() => router.push('/farm/add')}
          >
            <Text style={styles.addFarmText}>+ Add New Farm</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          
          <Card style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingLabelContainer}>
                <Bell size={20} color={colors.neutral[600]} />
                <Text style={styles.settingLabel}>Push Notifications</Text>
              </View>
              <Switch
                value={pushNotifications}
                onValueChange={setPushNotifications}
                trackColor={{ false: colors.neutral[300], true: colors.primary[300] }}
                thumbColor={pushNotifications ? colors.primary[500] : colors.neutral[100]}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLabelContainer}>
                <Globe size={20} color={colors.neutral[600]} />
                <Text style={styles.settingLabel}>Email Notifications</Text>
              </View>
              <Switch
                value={emailNotifications}
                onValueChange={setEmailNotifications}
                trackColor={{ false: colors.neutral[300], true: colors.primary[300] }}
                thumbColor={emailNotifications ? colors.primary[500] : colors.neutral[100]}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLabelContainer}>
                <Database size={20} color={colors.neutral[600]} />
                <Text style={styles.settingLabel}>Offline Mode</Text>
              </View>
              <Switch
                value={offlineMode}
                onValueChange={setOfflineMode}
                trackColor={{ false: colors.neutral[300], true: colors.primary[300] }}
                thumbColor={offlineMode ? colors.primary[500] : colors.neutral[100]}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLabelContainer}>
                <Image size={20} color={colors.neutral[600]} />
                <Text style={styles.settingLabel}>High Quality Images</Text>
              </View>
              <Switch
                value={highQualityImages}
                onValueChange={setHighQualityImages}
                trackColor={{ false: colors.neutral[300], true: colors.primary[300] }}
                thumbColor={highQualityImages ? colors.primary[500] : colors.neutral[100]}
              />
            </View>
          </Card>
          
          <TouchableOpacity 
            style={styles.settingButton} 
            onPress={handleSettingsPress}
          >
            <Settings size={20} color={colors.neutral[700]} />
            <Text style={styles.settingButtonText}>Advanced Settings</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingButton}>
            <HelpCircle size={20} color={colors.neutral[700]} />
            <Text style={styles.settingButtonText}>Help & Support</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingButton}>
            <Shield size={20} color={colors.neutral[700]} />
            <Text style={styles.settingButtonText}>Privacy & Security</Text>
          </TouchableOpacity>
        </View>
        
        <Button
          title="Logout"
          variant="outline"
          onPress={handleLogout}
          style={styles.logoutButton}
          icon={<LogOut size={20} color={colors.error[500]} />}
          textStyle={{ color: colors.error[500] }}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral[100],
  },
  scrollView: {
    flex: 1,
  },
  profileSection: {
    alignItems: 'center',
    backgroundColor: colors.white,
    paddingVertical: spacing.xl,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: spacing.md,
  },
  profileName: {
    ...typography.headingMedium,
    color: colors.neutral[800],
  },
  profileEmail: {
    ...typography.bodyMedium,
    color: colors.neutral[600],
    marginTop: spacing.xs,
  },
  roleBadge: {
    backgroundColor: colors.primary[100],
    paddingVertical: spacing.xxs,
    paddingHorizontal: spacing.sm,
    borderRadius: spacing.sm,
    marginTop: spacing.sm,
  },
  roleText: {
    ...typography.labelSmall,
    color: colors.primary[700],
  },
  editButton: {
    marginTop: spacing.md,
  },
  section: {
    padding: spacing.md,
  },
  sectionTitle: {
    ...typography.headingSmall,
    color: colors.neutral[800],
    marginBottom: spacing.md,
  },
  farmCard: {
    marginBottom: spacing.md,
  },
  farmHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  farmName: {
    ...typography.labelLarge,
    color: colors.neutral[800],
  },
  farmSize: {
    ...typography.bodySmall,
    color: colors.neutral[600],
  },
  farmLocation: {
    ...typography.bodySmall,
    color: colors.neutral[600],
    marginBottom: spacing.sm,
  },
  cropContainer: {
    flexDirection: 'row',
    marginTop: spacing.xs,
  },
  cropsLabel: {
    ...typography.bodySmall,
    color: colors.neutral[600],
    fontWeight: 'bold',
  },
  cropsText: {
    ...typography.bodySmall,
    color: colors.neutral[600],
    flex: 1,
  },
  addFarmButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.primary[300],
    borderRadius: spacing.sm,
    borderStyle: 'dashed',
  },
  addFarmText: {
    ...typography.labelMedium,
    color: colors.primary[500],
  },
  settingsCard: {
    marginBottom: spacing.md,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  settingLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingLabel: {
    ...typography.bodyMedium,
    color: colors.neutral[800],
    marginLeft: spacing.sm,
  },
  settingButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    padding: spacing.md,
    borderRadius: spacing.sm,
    marginBottom: spacing.sm,
  },
  settingButtonText: {
    ...typography.bodyMedium,
    color: colors.neutral[800],
    marginLeft: spacing.md,
  },
  logoutButton: {
    marginHorizontal: spacing.md,
    marginVertical: spacing.xl,
    borderColor: colors.error[300],
  },
});