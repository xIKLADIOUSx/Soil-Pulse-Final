import React, { useState, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { Header } from '@/components/Header';
import { AnalysisCard } from '@/components/AnalysisCard';
import { colors, spacing, typography } from '@/theme';
import { useRouter } from 'expo-router';
import { SoilAnalysisResult, SoilHealth, SoilDisease } from '@/types';
import { useNetworkStatus } from '@/utils/network';
import { Filter, Calendar, MapPin } from 'lucide-react-native';

// Mock data for demonstration
const mockAnalyses: SoilAnalysisResult[] = [
  {
    id: '1',
    userId: 'user1',
    farmId: 'farm1',
    imageUrl: 'https://images.pexels.com/photos/6024558/pexels-photo-6024558.jpeg',
    timestamp: Date.now() - 86400000 * 2, // 2 days ago
    location: {
      latitude: 37.7749,
      longitude: -122.4194,
      accuracy: 10
    },
    disease: {
      type: 'fungal_infection',
      confidence: 0.87,
      severity: 3.5
    },
    soilHealth: 'fair',
    recommendations: [
      'Apply fungicide treatment within 48 hours',
      'Improve drainage in affected areas',
      'Consider crop rotation next season'
    ],
    nutrients: {
      nitrogen: 12,
      phosphorus: 9,
      potassium: 18,
      ph: 6.2,
      organicMatter: 3.4
    },
    isSynced: true
  },
  {
    id: '2',
    userId: 'user1',
    farmId: 'farm1',
    imageUrl: 'https://images.pexels.com/photos/7728332/pexels-photo-7728332.jpeg',
    timestamp: Date.now() - 86400000 * 5, // 5 days ago
    location: {
      latitude: 37.7755,
      longitude: -122.4198,
      accuracy: 8
    },
    disease: {
      type: 'nutrient_deficiency',
      confidence: 0.92,
      severity: 2.0
    },
    soilHealth: 'good',
    recommendations: [
      'Apply balanced NPK fertilizer',
      'Consider soil amendment with compost'
    ],
    nutrients: {
      nitrogen: 8,
      phosphorus: 5,
      potassium: 12,
      ph: 6.7,
      organicMatter: 4.1
    },
    isSynced: true
  },
  {
    id: '3',
    userId: 'user1',
    farmId: 'farm1',
    imageUrl: 'https://images.pexels.com/photos/5474600/pexels-photo-5474600.jpeg',
    timestamp: Date.now() - 86400000 * 1, // 1 day ago
    location: {
      latitude: 37.7760,
      longitude: -122.4190,
      accuracy: 15
    },
    disease: {
      type: 'pest_damage',
      confidence: 0.78,
      severity: 4.2
    },
    soilHealth: 'poor',
    recommendations: [
      'Apply targeted pesticide immediately',
      'Monitor for signs of spread to adjacent areas',
      'Consider beneficial insects for long-term management'
    ],
    nutrients: {
      nitrogen: 14,
      phosphorus: 11,
      potassium: 10,
      ph: 5.9,
      organicMatter: 2.8
    },
    isSynced: false
  },
  {
    id: '4',
    userId: 'user1',
    farmId: 'farm1',
    imageUrl: 'https://images.pexels.com/photos/4505171/pexels-photo-4505171.jpeg',
    timestamp: Date.now() - 86400000 * 10, // 10 days ago
    location: {
      latitude: 37.7752,
      longitude: -122.4192,
      accuracy: 12
    },
    disease: {
      type: 'bacterial_wilt',
      confidence: 0.65,
      severity: 3.8
    },
    soilHealth: 'poor',
    recommendations: [
      'Remove and destroy infected plants',
      'Apply copper-based bactericide',
      'Avoid overhead irrigation'
    ],
    nutrients: {
      nitrogen: 15,
      phosphorus: 7,
      potassium: 9,
      ph: 5.5,
      organicMatter: 2.2
    },
    isSynced: true
  },
  {
    id: '5',
    userId: 'user1',
    farmId: 'farm1',
    imageUrl: 'https://images.pexels.com/photos/5417832/pexels-photo-5417832.jpeg',
    timestamp: Date.now() - 86400000 * 15, // 15 days ago
    location: {
      latitude: 37.7748,
      longitude: -122.4196,
      accuracy: 9
    },
    disease: {
      type: 'healthy',
      confidence: 0.94,
      severity: 0.5
    },
    soilHealth: 'excellent',
    recommendations: [
      'Maintain current soil management practices',
      'Consider cover crops for long-term soil health'
    ],
    nutrients: {
      nitrogen: 18,
      phosphorus: 12,
      potassium: 15,
      ph: 6.8,
      organicMatter: 5.2
    },
    isSynced: true
  }
];

export default function HistoryScreen() {
  const router = useRouter();
  const { isConnected } = useNetworkStatus();
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [analyses, setAnalyses] = useState<SoilAnalysisResult[]>(mockAnalyses);
  const [activeFilterType, setActiveFilterType] = useState<'all' | 'health' | 'date' | 'location'>('all');
  const [showFilters, setShowFilters] = useState(false);

  const handleAnalysisPress = (analysisId: string) => {
    router.push(`/analysis/${analysisId}`);
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    
    // Simulate API fetch
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  const applyHealthFilter = (health: SoilHealth) => {
    setLoading(true);
    
    // Simulate filter application
    setTimeout(() => {
      const filtered = mockAnalyses.filter(analysis => analysis.soilHealth === health);
      setAnalyses(filtered);
      setLoading(false);
      setActiveFilterType('health');
      setShowFilters(false);
    }, 500);
  };

  const applyDiseaseFilter = (disease: SoilDisease) => {
    setLoading(true);
    
    // Simulate filter application
    setTimeout(() => {
      const filtered = mockAnalyses.filter(analysis => analysis.disease.type === disease);
      setAnalyses(filtered);
      setLoading(false);
      setActiveFilterType('health');
      setShowFilters(false);
    }, 500);
  };

  const applyDateFilter = (days: number) => {
    setLoading(true);
    
    // Simulate filter application
    setTimeout(() => {
      const cutoffDate = Date.now() - (86400000 * days);
      const filtered = mockAnalyses.filter(analysis => analysis.timestamp >= cutoffDate);
      setAnalyses(filtered);
      setLoading(false);
      setActiveFilterType('date');
      setShowFilters(false);
    }, 500);
  };

  const resetFilters = () => {
    setLoading(true);
    
    // Simulate filter reset
    setTimeout(() => {
      setAnalyses(mockAnalyses);
      setLoading(false);
      setActiveFilterType('all');
      setShowFilters(false);
    }, 500);
  };

  const renderFilterOptions = () => {
    if (!showFilters) return null;
    
    return (
      <View style={styles.filtersContainer}>
        <Text style={styles.filterTitle}>Filter by:</Text>
        
        <View style={styles.filterSection}>
          <Text style={styles.filterSectionTitle}>Soil Health</Text>
          <View style={styles.filterOptionsRow}>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyHealthFilter('excellent')}
            >
              <Text style={styles.filterChipText}>Excellent</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyHealthFilter('good')}
            >
              <Text style={styles.filterChipText}>Good</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyHealthFilter('fair')}
            >
              <Text style={styles.filterChipText}>Fair</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.filterOptionsRow}>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyHealthFilter('poor')}
            >
              <Text style={styles.filterChipText}>Poor</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyHealthFilter('critical')}
            >
              <Text style={styles.filterChipText}>Critical</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.filterSection}>
          <Text style={styles.filterSectionTitle}>Date Range</Text>
          <View style={styles.filterOptionsRow}>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyDateFilter(7)}
            >
              <Text style={styles.filterChipText}>Last 7 days</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyDateFilter(30)}
            >
              <Text style={styles.filterChipText}>Last 30 days</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.filterChip} 
              onPress={() => applyDateFilter(90)}
            >
              <Text style={styles.filterChipText}>Last 90 days</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <TouchableOpacity 
          style={styles.resetButton} 
          onPress={resetFilters}
        >
          <Text style={styles.resetButtonText}>Reset Filters</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Header 
        title="Analysis History" 
        rightComponent={
          <TouchableOpacity onPress={toggleFilters} style={styles.filterButton}>
            <Filter size={24} color={colors.neutral[800]} />
          </TouchableOpacity>
        }
      />
      
      {renderFilterOptions()}
      
      {activeFilterType !== 'all' && (
        <View style={styles.activeFiltersContainer}>
          <Text style={styles.activeFiltersText}>
            Active filters: {activeFilterType === 'health' ? 'Soil Health' : 
                             activeFilterType === 'date' ? 'Date Range' :
                             activeFilterType === 'location' ? 'Location' : ''}
          </Text>
          <TouchableOpacity onPress={resetFilters}>
            <Text style={styles.clearFiltersText}>Clear</Text>
          </TouchableOpacity>
        </View>
      )}

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary[500]} />
          <Text style={styles.loadingText}>Loading results...</Text>
        </View>
      ) : (
        <FlatList
          data={analyses}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <AnalysisCard 
              analysis={item}
              onPress={() => handleAnalysisPress(item.id)}
            />
          )}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No analysis results found</Text>
              <Text style={styles.emptySubtext}>Try different filters or create a new scan</Text>
            </View>
          }
        />
      )}
      
      {!isConnected && (
        <View style={styles.offlineContainer}>
          <Text style={styles.offlineText}>
            You're currently offline. Some analyses may not be available.
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral[100],
  },
  filterButton: {
    padding: spacing.xs,
  },
  filtersContainer: {
    backgroundColor: colors.white,
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  filterTitle: {
    ...typography.labelLarge,
    color: colors.neutral[800],
    marginBottom: spacing.md,
  },
  filterSection: {
    marginBottom: spacing.md,
  },
  filterSectionTitle: {
    ...typography.labelMedium,
    color: colors.neutral[600],
    marginBottom: spacing.sm,
  },
  filterOptionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: spacing.xs,
  },
  filterChip: {
    backgroundColor: colors.primary[50],
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    borderRadius: 20,
    marginRight: spacing.sm,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.primary[100],
  },
  filterChipText: {
    ...typography.bodySmall,
    color: colors.primary[700],
  },
  resetButton: {
    alignSelf: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: spacing.sm,
    borderWidth: 1,
    borderColor: colors.neutral[300],
    marginTop: spacing.sm,
  },
  resetButtonText: {
    ...typography.labelMedium,
    color: colors.neutral[700],
  },
  activeFiltersContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.neutral[50],
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral[200],
  },
  activeFiltersText: {
    ...typography.bodyMedium,
    color: colors.neutral[700],
  },
  clearFiltersText: {
    ...typography.labelMedium,
    color: colors.primary[500],
  },
  listContent: {
    padding: spacing.md,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...typography.bodyMedium,
    color: colors.neutral[600],
    marginTop: spacing.md,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
    marginTop: spacing.xxl,
  },
  emptyText: {
    ...typography.headingMedium,
    color: colors.neutral[600],
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    ...typography.bodyMedium,
    color: colors.neutral[500],
    textAlign: 'center',
  },
  offlineContainer: {
    backgroundColor: colors.warning[500],
    padding: spacing.md,
  },
  offlineText: {
    ...typography.bodyMedium,
    color: colors.white,
    textAlign: 'center',
  },
});