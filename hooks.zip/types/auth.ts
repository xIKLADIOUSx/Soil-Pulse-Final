/**
 * Auth types for the SoilSense AI app
 */

export type UserRole = 'farmer' | 'agronomist' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  farms?: Farm[];
  profileImageUrl?: string;
}

export interface Farm {
  id: string;
  name: string;
  location: {
    latitude: number;
    longitude: number;
  };
  size: number; // in acres/hectares
  crops: string[];
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}